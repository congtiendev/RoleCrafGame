# HUY – Senior Developer Sprite Pack

## Các sheet

| File | Lưới | Nội dung |
|---|---:|---|
| `HUY_A_master.png` | Master mẫu | Sprite gốc do người dùng cung cấp; dùng làm chuẩn nhận diện và phong cách |
| `HUY_B_hands_gestures.png` | 8 × 7 | Báo cáo tiến độ, giải thích kỹ thuật, ước lượng, điện thoại, bàn giao, mentoring và giãn cơ |
| `HUY_C_work_scenes.png` | 8 × 7 | Code, họp, 1-1, incident/rollback, quá tải, Technical Lead/rời team và cảnh kết |
| `HUY_D_portraits.png` | 4 × 5 | 20 chân dung cảm xúc dùng trong hộp thoại |

Tất cả file là PNG RGBA nền trong suốt. Các sheet được giữ nguyên, không cắt thành từng sprite riêng.

## Quy ước sử dụng

- Đọc ô từ trái sang phải, từ trên xuống dưới.
- Sheet B và C có 56 ô; Sheet D có 20 ô.
- Áo, gương mặt, tóc và tỷ lệ nhân vật bám theo `HUY_A_master.png`.
- Không sử dụng ảnh chân dung thật trong quy trình tạo B, C, D.
- Chấm neo magenta `#FF00FF`: vị trí vật cầm chính.
- Chấm neo xanh lá `#00FF00`: vị trí vật cầm thứ hai.
- Chấm neo cyan `#00FFFF`: điểm tiếp xúc ghế của tư thế ngồi.
- Tên animation và gợi ý gắn theo kịch bản nằm trong `docs_and_prompts/README_HUY_SPRITE_PROMPTS.md`.
- Thứ tự ô và key kỹ thuật nằm trong `docs_and_prompts/huy_sprite_manifest.json`.

## Khi cần sinh lại

Các prompt gốc được giữ trong `docs_and_prompts/prompts/`. Với bộ này, bỏ phần yêu cầu ảnh người thật và dùng duy nhất `HUY_A_master.png` làm nguồn nhận diện, trang phục và phong cách. Luôn yêu cầu nền trong suốt thay cho nền trắng.

